Description
-----------
The grididloader assigns Grid Identifiers to all caBIO domain objects. 

Running
-------
This program is usually run automatically by the caBIO loading scripts. 
For manual running instructions see, build.xml.
