DROP PUBLIC SYNONYM PROTOCOL
/

--
-- PROTOCOL  (Synonym) 
--
--  Dependencies: 
--   PROTOCOL (Column)
--
CREATE PUBLIC SYNONYM PROTOCOL FOR PROTOCOL
/


