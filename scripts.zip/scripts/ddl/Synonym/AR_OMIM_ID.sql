DROP PUBLIC SYNONYM AR_OMIM_ID
/

--
-- AR_OMIM_ID  (Synonym) 
--
--  Dependencies: 
--   AR_OMIM_ID (Table)
--
CREATE PUBLIC SYNONYM AR_OMIM_ID FOR AR_OMIM_ID
/


