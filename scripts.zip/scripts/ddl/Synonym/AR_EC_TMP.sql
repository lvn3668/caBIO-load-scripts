DROP PUBLIC SYNONYM AR_EC_TMP
/

--
-- AR_EC_TMP  (Synonym) 
--
--  Dependencies: 
--   AR_EC_TMP (Table)
--
CREATE PUBLIC SYNONYM AR_EC_TMP FOR AR_EC_TMP
/


