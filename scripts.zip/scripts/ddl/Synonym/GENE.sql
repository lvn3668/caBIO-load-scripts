DROP PUBLIC SYNONYM GENE
/

--
-- GENE  (Synonym) 
--
--  Dependencies: 
--   GENE (Table)
--
CREATE PUBLIC SYNONYM GENE FOR GENE
/


