DROP PUBLIC SYNONYM SNPSEQ
/

--
-- SNPSEQ  (Synonym) 
--
--  Dependencies: 
--   SNPSEQ (Table)
--
CREATE PUBLIC SYNONYM SNPSEQ FOR SNPSEQ
/


