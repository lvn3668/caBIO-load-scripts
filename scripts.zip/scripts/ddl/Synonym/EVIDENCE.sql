DROP PUBLIC SYNONYM EVIDENCE
/

--
-- EVIDENCE  (Synonym) 
--
--  Dependencies: 
--   EVIDENCE (Column)
--
CREATE PUBLIC SYNONYM EVIDENCE FOR EVIDENCE
/


