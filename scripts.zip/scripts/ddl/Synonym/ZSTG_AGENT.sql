DROP PUBLIC SYNONYM ZSTG_AGENT
/

--
-- ZSTG_AGENT  (Synonym) 
--
--  Dependencies: 
--   ZSTG_AGENT (Table)
--
CREATE PUBLIC SYNONYM ZSTG_AGENT FOR ZSTG_AGENT
/


