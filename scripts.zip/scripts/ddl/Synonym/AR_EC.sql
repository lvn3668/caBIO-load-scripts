DROP PUBLIC SYNONYM AR_EC
/

--
-- AR_EC  (Synonym) 
--
--  Dependencies: 
--   AR_EC (Table)
--
CREATE PUBLIC SYNONYM AR_EC FOR AR_EC
/


