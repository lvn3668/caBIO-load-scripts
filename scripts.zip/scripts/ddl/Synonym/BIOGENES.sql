DROP PUBLIC SYNONYM BIOGENES
/

--
-- BIOGENES  (Synonym) 
--
--  Dependencies: 
--   BIOGENES (Table)
--
CREATE PUBLIC SYNONYM BIOGENES FOR BIOGENES
/


