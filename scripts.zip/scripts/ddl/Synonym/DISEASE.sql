DROP PUBLIC SYNONYM DISEASE
/

--
-- DISEASE  (Synonym) 
--
--  Dependencies: 
--   DISEASE (Table)
--
CREATE PUBLIC SYNONYM DISEASE FOR DISEASE
/


