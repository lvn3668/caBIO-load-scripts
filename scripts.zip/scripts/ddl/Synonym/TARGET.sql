DROP PUBLIC SYNONYM TARGET
/

--
-- TARGET  (Synonym) 
--
--  Dependencies: 
--   TARGET (Table)
--
CREATE PUBLIC SYNONYM TARGET FOR TARGET
/


