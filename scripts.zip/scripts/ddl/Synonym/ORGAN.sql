DROP PUBLIC SYNONYM ORGAN
/

--
-- ORGAN  (Synonym) 
--
--  Dependencies: 
--   ORGAN (Table)
--
CREATE PUBLIC SYNONYM ORGAN FOR ORGAN
/


