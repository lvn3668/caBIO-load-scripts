DROP PUBLIC SYNONYM ANOMALY
/

--
-- ANOMALY  (Synonym) 
--
--  Dependencies: 
--   ANOMALY (Table)
--
CREATE PUBLIC SYNONYM ANOMALY FOR ANOMALY
/


