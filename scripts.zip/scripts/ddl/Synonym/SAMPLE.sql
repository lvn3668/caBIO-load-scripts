DROP PUBLIC SYNONYM SAMPLE
/

--
-- SAMPLE  (Synonym) 
--
--  Dependencies: 
--   SAMPLE (Table)
--
CREATE PUBLIC SYNONYM SAMPLE FOR SAMPLE
/


