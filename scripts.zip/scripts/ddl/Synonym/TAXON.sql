DROP PUBLIC SYNONYM TAXON
/

--
-- TAXON  (Synonym) 
--
--  Dependencies: 
--   TAXON (Column)
--
CREATE PUBLIC SYNONYM TAXON FOR TAXON
/


