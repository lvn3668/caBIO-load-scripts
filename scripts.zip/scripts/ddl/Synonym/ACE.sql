DROP PUBLIC SYNONYM ACE
/

--
-- ACE  (Synonym) 
--
--  Dependencies: 
--   ACE (Table)
--
CREATE PUBLIC SYNONYM ACE FOR ACE
/


