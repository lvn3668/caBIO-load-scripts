DROP PUBLIC SYNONYM CLONE_TV
/

--
-- CLONE_TV  (Synonym) 
--
--  Dependencies: 
--   CLONE_TV (Table)
--
CREATE PUBLIC SYNONYM CLONE_TV FOR CLONE_TV
/


