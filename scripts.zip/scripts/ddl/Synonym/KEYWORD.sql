DROP PUBLIC SYNONYM KEYWORD
/

--
-- KEYWORD  (Synonym) 
--
--  Dependencies: 
--   KEYWORD (Table)
--
CREATE PUBLIC SYNONYM KEYWORD FOR KEYWORD
/


