DROP PUBLIC SYNONYM AGENT
/

--
-- AGENT  (Synonym) 
--
--  Dependencies: 
--   AGENT (Table)
--
CREATE PUBLIC SYNONYM AGENT FOR AGENT
/


