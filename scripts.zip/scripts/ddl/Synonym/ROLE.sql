DROP PUBLIC SYNONYM ROLE
/

--
-- ROLE  (Synonym) 
--
--  Dependencies: 
--   ROLE (Table)
--
CREATE PUBLIC SYNONYM ROLE FOR ROLE
/


