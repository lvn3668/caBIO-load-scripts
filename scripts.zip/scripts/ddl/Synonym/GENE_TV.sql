DROP PUBLIC SYNONYM GENE_TV
/

--
-- GENE_TV  (Synonym) 
--
--  Dependencies: 
--   GENE_TV (Table)
--
CREATE PUBLIC SYNONYM GENE_TV FOR GENE_TV
/


