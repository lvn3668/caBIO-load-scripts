DROP PUBLIC SYNONYM EXON
/

--
-- EXON  (Synonym) 
--
--  Dependencies: 
--   EXON (Table)
--
CREATE PUBLIC SYNONYM EXON FOR EXON
/


