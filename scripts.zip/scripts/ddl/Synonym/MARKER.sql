DROP PUBLIC SYNONYM MARKER
/

--
-- MARKER  (Synonym) 
--
--  Dependencies: 
--   MARKER (Table)
--
CREATE PUBLIC SYNONYM MARKER FOR MARKER
/


