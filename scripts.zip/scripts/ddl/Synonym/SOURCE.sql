DROP PUBLIC SYNONYM SOURCE
/

--
-- SOURCE  (Synonym) 
--
--  Dependencies: 
--   SOURCE (Column)
--
CREATE PUBLIC SYNONYM SOURCE FOR SOURCE
/


