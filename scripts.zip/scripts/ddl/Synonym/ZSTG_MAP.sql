DROP PUBLIC SYNONYM ZSTG_MAP
/

--
-- ZSTG_MAP  (Synonym) 
--
--  Dependencies: 
--   ZSTG_MAP (Table)
--
CREATE PUBLIC SYNONYM ZSTG_MAP FOR ZSTG_MAP
/


