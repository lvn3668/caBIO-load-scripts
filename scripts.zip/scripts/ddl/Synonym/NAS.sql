DROP PUBLIC SYNONYM NAS
/

--
-- NAS  (Synonym) 
--
--  Dependencies: 
--   NAS (Table)
--
CREATE PUBLIC SYNONYM NAS FOR NAS
/


