DROP PUBLIC SYNONYM SNP_TV
/

--
-- SNP_TV  (Synonym) 
--
--  Dependencies: 
--   SNP_TV (Table)
--
CREATE PUBLIC SYNONYM SNP_TV FOR SNP_TV
/


