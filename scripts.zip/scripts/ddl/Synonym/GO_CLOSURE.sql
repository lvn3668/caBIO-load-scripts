DROP PUBLIC SYNONYM GO_CLOSURE
/

--
-- GO_CLOSURE  (Synonym) 
--
--  Dependencies: 
--   GO_CLOSURE (Table)
--
CREATE PUBLIC SYNONYM GO_CLOSURE FOR GO_CLOSURE
/


